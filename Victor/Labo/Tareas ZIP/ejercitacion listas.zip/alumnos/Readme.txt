## Algoritmos 2 -- Taller de Lista Enlazada

### Consigna

1) Implementar una lista doblemente enlazada, es decir, que cada nodo esté conectado con el siguiente y con el anterior (a diferencia de la lista simple). Los elemento deben poder ser de cualquier tipo de datos

* Elegir una representación y agregarla a la parte privada de la clase Lista
* Implementar todos los métodos de Lista sobre la estructura elegida

### Instrucciones

* Bajarse el zip con la consigna a una carpeta
* Importar el proyecto en CLion
* Codear!
* No cambiar los nombres de Lista.h y Lista.hpp al subir al repo.

